# fastcampus-backend
* Ch2 Nosql Redis with v6.2
* Ch3 Spring Webflux with Java 17 and Spring Boot 3
* Ch4 Project using spring webflux and redis
