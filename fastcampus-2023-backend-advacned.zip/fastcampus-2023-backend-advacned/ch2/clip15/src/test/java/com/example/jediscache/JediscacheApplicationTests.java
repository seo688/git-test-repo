package com.example.jediscache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JediscacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
