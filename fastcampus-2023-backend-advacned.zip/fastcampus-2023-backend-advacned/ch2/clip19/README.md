```
mkdir -p prometheus/data
mkdir -p prometheus/config
mkdir -p grafana/data
mkdir -p grafana/provisioning

docker-compose up -d
```
