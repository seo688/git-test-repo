package com.fastcampus.flow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
