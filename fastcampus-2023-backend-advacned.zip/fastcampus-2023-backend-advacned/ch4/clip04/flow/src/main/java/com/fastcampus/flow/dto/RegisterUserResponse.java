package com.fastcampus.flow.dto;

public record RegisterUserResponse(Long rank) {
}
