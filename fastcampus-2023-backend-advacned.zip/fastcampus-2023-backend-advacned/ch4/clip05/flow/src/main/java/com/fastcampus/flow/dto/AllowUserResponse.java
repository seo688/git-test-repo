package com.fastcampus.flow.dto;

public record AllowUserResponse(Long requestCount, Long allowedCount) {
}
