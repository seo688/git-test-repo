package com.fastcampus.flow.dto;

public record AllowedUserResponse(Boolean allowed) {
}
