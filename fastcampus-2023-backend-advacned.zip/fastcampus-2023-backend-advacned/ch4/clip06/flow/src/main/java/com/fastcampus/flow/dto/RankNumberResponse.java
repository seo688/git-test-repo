package com.fastcampus.flow.dto;

public record RankNumberResponse(Long rank) {
}
