package com.example.demo.entity;

public interface PrimaryKey {
    void setId(Long id);
    Long getId();
}
