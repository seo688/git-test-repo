package com.fastcampus.batchcampus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatchCampusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchCampusApplication.class, args);
	}

}
