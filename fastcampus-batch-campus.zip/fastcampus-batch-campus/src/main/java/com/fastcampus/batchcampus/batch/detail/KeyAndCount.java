package com.fastcampus.batchcampus.batch.detail;

public record KeyAndCount(Key key, Long count) {
}
