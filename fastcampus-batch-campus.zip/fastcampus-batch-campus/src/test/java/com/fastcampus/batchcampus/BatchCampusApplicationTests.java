package com.fastcampus.batchcampus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchCampusApplicationTests {

	@Test
	void contextLoads() {
	}

}
