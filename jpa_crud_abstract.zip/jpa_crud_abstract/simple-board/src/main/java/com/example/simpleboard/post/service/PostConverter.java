package com.example.simpleboard.post.service;

import com.example.simpleboard.post.db.PostEntity;
import com.example.simpleboard.post.model.PostDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PostConverter {

    public PostDto toDto(PostEntity postEntity){
        postEntity.getReplyList().stream()
                .map(it -> {
                    log.info("replyList : {} ", it);
                    return it;
                });


        return PostDto.builder()
            .id(postEntity.getId())
            .userName(postEntity.getUserName())
            .status(postEntity.getStatus())
            .email(postEntity.getEmail())
            .password(postEntity.getPassword())
            .title(postEntity.getTitle())
            .content(postEntity.getContent())
            .postedAt(postEntity.getPostedAt())
            .boardId(postEntity.getBoardEntity().getId())
            .build()
            ;
    }
}
