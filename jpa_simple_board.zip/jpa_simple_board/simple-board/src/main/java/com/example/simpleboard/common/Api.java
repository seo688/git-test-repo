package com.example.simpleboard.common;

import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Api<T> {

    private T body;

    private Pagination pagination;
}
